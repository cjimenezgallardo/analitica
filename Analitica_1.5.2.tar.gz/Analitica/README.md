# Analitica 📊

**Analitica** es un paquete en R para realizar análisis descriptivo de variables numéricas con y sin variables independientes, con visualizaciones automáticas.

## 📦 Instalación

```r
# Desde archivo local
install.packages("Analitica_0.2.0.tar.gz", repos = NULL, type = "source")
