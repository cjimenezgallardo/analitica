#' Summary method for comparison-based test objects
#'
#' @param object An object of class 'comparacion'.
#' @param ... Additional arguments (ignored).
#' @return Invisibly returns the summary table.
#'
#'
#' @examples
#' data(d_e, package = "Analitica")
#' mod <- aov(Sueldo_actual ~ as.factor(labor), data = d_E) # labor is numeric
#' resultado <- ScheffeTest(mod)
#' summary(resultado)
#'
#'
#' @export
summary.comparacion <- function(object, ...) {
  metodo <- if (!is.null(object$Metodo)) object$Metodo else "comparacion"
  resultados <- object$Resultados
  promedios <- object$Promedios
  orden <- object$Orden_Medias

  cat("Resumen del test de", metodo, "\n")
  cat(strrep("=", 30), "\n\n")

  # Mostrar tabla de comparaciones
  print(resultados, row.names = FALSE)

  # Mostrar promedios ordenados
  cat("\nPromedios por grupo (ordenados de mayor a menor):\n")
  ordenado <- round(promedios[orden], 3)
  print(ordenado)

  invisible(resultados)
}
