#' Tamhane T2 Post Hoc Test
#'
#' Performs the Tamhane T2 test for pairwise comparisons after ANOVA,
#' suitable when variances are unequal and/or sample sizes differ.
#'
#' @param modelo An object from \code{aov} or \code{lm}.
#' @param alpha Significance level (default is 0.05).
#'
#' @return An object of class \code{"tamhanet2"} and \code{"comparacion"}.
#' @export
#'
#' @examples
#' data(d_e, package = "Analitica")
#' mod <- aov(Sueldo_actual ~ as.factor(labor), data = d_E) # labor is numeric
#' resultado <- T2Test(mod)
#' summary(resultado)
#' plot(resultado)
#'
#'
T2Test <- function(modelo, alpha = 0.05) {
  factor_name <- names(modelo$xlevels)[1]
  grupos <- modelo$model[[factor_name]]
  respuesta <- modelo$model[[1]]

  medias <- tapply(respuesta, grupos, mean)
  n <- tapply(respuesta, grupos, length)
  s2 <- tapply(respuesta, grupos, var)
  nombres_grupos <- names(medias)

  comparaciones <- combn(nombres_grupos, 2, simplify = FALSE)

  resultados <- data.frame(
    Comparacion = character(),
    Diferencia = numeric(),
    t_value = numeric(),
    gl = numeric(),
    p_value = numeric(),
    Significancia = character(),
    stringsAsFactors = FALSE
  )

  for (par in comparaciones) {
    g1 <- par[1]
    g2 <- par[2]

    dif <- abs(medias[g1] - medias[g2])
    se_ij <- sqrt((s2[g1] / n[g1]) + (s2[g2] / n[g2]))

    # Welch-Satterthwaite degrees of freedom
    df_num <- (s2[g1] / n[g1] + s2[g2] / n[g2])^2
    df_den <- ((s2[g1]^2) / (n[g1]^2 * (n[g1] - 1))) + ((s2[g2]^2) / (n[g2]^2 * (n[g2] - 1)))
    gl <- df_num / df_den

    t_val <- dif / se_ij
    # Bonferroni-adjusted p-value for multiple comparisons (conservative)
    p_val <- 2 * pt(-abs(t_val), df = gl)

    sig <- ifelse(p_val < alpha, "*", "ns")

    # Ordenar nombres para coincidir con plot.comparacion()
    nombres_ordenados <- sort(c(g1, g2))
    comparacion <- paste(nombres_ordenados, collapse = " - ")

    resultados <- rbind(resultados, data.frame(
      Comparacion = comparacion,
      Diferencia = round(dif, 4),
      t_value = round(t_val, 4),
      gl = round(gl, 2),
      p_value = round(p_val, 4),
      Significancia = sig
    ))
  }

  # Ordenar los nombres de los grupos por media (de mayor a menor)
  ordenado <- names(sort(medias, decreasing = TRUE))

  out <- list(
    Resultados = resultados,
    Promedios = medias,
    Orden_Medias = ordenado,
    Metodo = "Tamhane T2"
  )
  class(out) <- c("comparacion", "tamhanet2")

  return(out)
}
