#' Brunner-Munzel Test for Two Independent Groups (Standardized)
#'
#' Performs the Brunner-Munzel non-parametric test for two independent groups.
#' Compatible with generic 'comparacion' methods (summary, plot).
#'
#' @param grupo1 Numeric vector for the first group.
#' @param grupo2 Numeric vector for the second group.
#' @param alpha Significance level (default = 0.05).
#' @param alternative alternative Hypotesis: "two.sided", "greater", o "less".
#'
#' @return An object of class \code{"comparacion"} with:
#' \describe{
#'   \item{Resultados}{Data frame of the pairwise comparison.}
#'   \item{Promedios}{Named vector of group means.}
#'   \item{Orden_Medias}{Names of groups ordered from highest to lowest mean.}
#'   \item{Metodo}{Name of the test used ("Brunner-Munzel").}
#' }
#'
#' @importFrom stats qt pt
#'
#' @export
#'
#' @examples
#' data(d_e, package = "Analitica")
#' g1<-d_E$Sueldo_actual[d_E$labor==1]
#' g2<-d_E$Sueldo_actual[d_E$labor==2]
#' resultado<-BMTest(g1,g2,alternative="greater")
#' summary(resultado)
#'
#'
#'
BMTest <- function(grupo1, grupo2, alpha = 0.05, alternative = c("two.sided", "less", "greater")) {
  alternative <- match.arg(alternative)

  m <- length(grupo1)
  n <- length(grupo2)

  datos <- c(grupo1, grupo2)
  rangos <- rank(datos)

  R1 <- rangos[1:m]
  R2 <- rangos[(m + 1):(m + n)]

  R1_bar <- mean(R1)
  R2_bar <- mean(R2)

  S1_sq <- sum((R1 - R1_bar)^2) / (m - 1)
  S2_sq <- sum((R2 - R2_bar)^2) / (n - 1)

  S_sq <- (S1_sq / m) + (S2_sq / n)
  T_stat <- (R1_bar - R2_bar) / sqrt(S_sq)

  df_num <- S_sq^2
  df_den <- (S1_sq^2 / (m^2 * (m - 1))) + (S2_sq^2 / (n^2 * (n - 1)))
  df <- df_num / df_den

  # Valor p según alternativa
  p_val <- switch(alternative,
                  "two.sided" = 2 * (1 - pt(abs(T_stat), df)),
                  "greater" = 1 - pt(T_stat, df),
                  "less" = pt(T_stat, df))

  nombres <- c("Grupo1", "Grupo2")
  medias <- c(mean(grupo1), mean(grupo2))
  names(medias) <- nombres
  orden <- order(medias, decreasing = TRUE)
  etiquetas_ordenadas <- names(medias)[orden]

  diferencia <- abs(medias[1] - medias[2])
  SE <- sqrt(S_sq)
  t_crit <- qt(1 - alpha / 2, df)
  valor_critico <- t_crit * SE
  sig <- ifelse(p_val < alpha, "*", "ns")

  resultados <- data.frame(
    Comparacion = paste(nombres[1], nombres[2], sep = " - "),
    Diferencia = diferencia,
    Valor_Critico = valor_critico,
    p_value = round(p_val, 4),
    Significancia = sig,
    stringsAsFactors = FALSE
  )

  out <- list(
    Resultados = resultados,
    Promedios = medias,
    Orden_Medias = etiquetas_ordenadas,
    Metodo = paste("Brunner-Munzel (", alternative, ")", sep = "")
  )
  class(out) <- c("comparacion", "brunnermunzel")

  return(out)
}
