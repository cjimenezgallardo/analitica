#' Levene Test for Homogeneity of Variances (manual)
#'
#' Performs Levene's test for equality of variances across groups using deviations
#' from the group medians. Robust to non-normal distributions.
#'
#' @param modelo An object from \code{aov} or \code{lm}.
#' @param alpha Significance level (default = 0.05).
#' @param center Use "median" (default) or "mean" for deviation calculation.
#'
#' @return A list of class \code{"homocedasticidad"} with:
#' \describe{
#'   \item{Estadistico}{F statistic.}
#'   \item{gl}{Degrees of freedom (between and within).}
#'   \item{p_value}{P-value for the test.}
#'   \item{Decision}{Conclusion about equal or unequal variances.}
#'   \item{Metodo}{Name of the method used.}
#' }
#'
#' @importFrom stats pf
#' @export
#'
#' @examples
#' data(d_e, package = "Analitica")
#' mod <- aov(Sueldo_actual ~ as.factor(labor), data = d_E) # labor is numeric
#' resultado <- Levene.Test(mod)
#' summary(resultado)
#'
Levene.Test <- function(modelo, alpha = 0.05, center = "median") {
  factor_name <- names(modelo$xlevels)[1]
  grupos <- modelo$model[[factor_name]]
  respuesta <- modelo$model[[1]]
  grupo_niveles <- unique(grupos)

  # Calcular desviaciones absolutas respecto al centro
  z <- numeric(length(respuesta))
  for (g in grupo_niveles) {
    idx <- grupos == g
    centro <- if (center == "mean") mean(respuesta[idx]) else median(respuesta[idx])
    z[idx] <- abs(respuesta[idx] - centro)
  }

  # ANOVA sobre las desviaciones
  df_total <- length(z) - 1
  df_between <- length(grupo_niveles) - 1
  df_within <- df_total - df_between

  medias_z <- tapply(z, grupos, mean)
  n <- tapply(z, grupos, length)
  overall_mean <- mean(z)

  # Suma de cuadrados
  SS_between <- sum(n * (medias_z - overall_mean)^2)
  SS_within <- sum((z - rep(medias_z, times = n))^2)

  MS_between <- SS_between / df_between
  MS_within <- SS_within / df_within
  F_stat <- MS_between / MS_within
  p_val <- 1 - pf(F_stat, df_between, df_within)

  decision <- ifelse(p_val < alpha, "Heterocedastic", "Homocedastic")

  out <- list(
    Estadistico = round(F_stat, 4),
    gl = c(df_between = df_between, df_within = df_within),
    p_value = round(p_val, 4),
    Decision = decision,
    Metodo = paste("Levene (", center, ")", sep = "")
  )
  class(out) <- "homocedasticidad"
  return(out)
}
