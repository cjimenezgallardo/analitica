#' Fligner-Killeen Test for Homogeneity of Variances (manual)
#'
#' Performs a non-parametric Fligner-Killeen test for equality of variances across groups.
#' Very robust to non-normality and outliers.
#'
#' @param modelo An object from \code{aov} or \code{lm}.
#' @param alpha Significance level (default = 0.05).
#'
#' @return A list of class \code{"homocedasticidad"} with:
#' \describe{
#'   \item{Estadistico}{Chi-squared statistic.}
#'   \item{gl}{Degrees of freedom.}
#'   \item{p_value}{P-value for the test.}
#'   \item{Decision}{Conclusion about equal or unequal variances.}
#'   \item{Metodo}{Name of the method used.}
#' }
#'
#' @export
#' @examples
#' data(d_e, package = "Analitica")
#' mod <- aov(Sueldo_actual ~ as.factor(labor), data = d_E) # labor is numeric
#' resultado <- FKTest(mod)
#' summary(resultado)
#'
#'
#'
#'
FKTest <- function(modelo, alpha = 0.05) {
  factor_name <- names(modelo$xlevels)[1]
  grupos <- modelo$model[[factor_name]]
  respuesta <- modelo$model[[1]]
  grupo_niveles <- unique(grupos)
  k <- length(grupo_niveles)

  # Medianas por grupo
  mediana_grupo <- tapply(respuesta, grupos, median)

  # Z_i = |X_ij - mediana_grupo|
  z <- abs(respuesta - mediana_grupo[grupos])

  # Rango de z (ranks)
  rangos <- rank(z)

  # Transformación logarítmica: ln(rank + 0.5)
  y <- log(rangos + 0.5)

  # Media general de y
  y_barra <- mean(y)

  # Media por grupo
  y_grupo <- tapply(y, grupos, mean)
  n <- tapply(y, grupos, length)

  # Estadístico X² = sum( n_i * (ȳ_i - ȳ)^2 )
  X2 <- sum(n * (y_grupo - y_barra)^2)

  gl <- k - 1
  p_val <- 1 - pchisq(X2, gl)
  decision <- ifelse(p_val < alpha, "Heterocedastic", "Homocedastic")

  out <- list(
    Estadistico = round(X2, 4),
    gl = gl,
    p_value = round(p_val, 4),
    Decision = decision,
    Metodo = "Fligner-Killeen"
  )
  class(out) <- "homocedasticidad"
  return(out)
}
