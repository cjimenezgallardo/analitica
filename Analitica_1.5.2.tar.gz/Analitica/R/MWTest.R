#' Mann Whitney U Test (Manual Implementation)
#'
#' Performs the Mann Whitney U test (Wilcoxon rank-sum) manually, with optional one-sided or two-sided alternative.
#' Compatible with 'comparacion' class (summary, plot).
#'
#' @param grupo1 Numeric vector for first group.
#' @param grupo2 Numeric vector for second group.
#' @param alpha Significance level (default = 0.05).
#' @param alternative Character string: "two.sided" (default), "less", or "greater".
#' @param continuity Logical: apply continuity correction (default = TRUE).
#'
#' @return A list of class 'comparacion'.
#'
#'
#' @importFrom stats pnorm
#'
#' @export
#' @examples
#' data(d_e, package = "Analitica")
#' g1<-d_E$Sueldo_actual[d_E$labor==1]
#' g2<-d_E$Sueldo_actual[d_E$labor==2]
#' resultado<-MWTest(g1,g2,alternative="greater")
#' summary(resultado)
#'
#'
MWTest <- function(grupo1, grupo2, alpha = 0.05, alternative = c("two.sided", "less", "greater"), continuity = TRUE) {
  alternative <- match.arg(alternative)

  m <- length(grupo1)
  n <- length(grupo2)

  datos <- c(grupo1, grupo2)
  rangos <- rank(datos)

  # Asignar rangos a cada grupo
  R1 <- sum(rangos[1:m])
  R2 <- sum(rangos[(m + 1):(m + n)])

  # Calcular U
  U1 <- R1 - m * (m + 1) / 2
  U2 <- m * n - U1

  # Estadistica U y su media/varianza
  U <- U1
  mu_U <- m * n / 2
  sigma_U <- sqrt(m * n * (m + n + 1) / 12)

  # Correccion de continuidad
  z <- switch(alternative,
              "two.sided" = {
                z0 <- (U - mu_U - if (continuity) 0.5 * sign(U - mu_U) else 0) / sigma_U
                2 * (1 - pnorm(abs(z0)))
              },
              "greater" = {
                z0 <- (U - mu_U - if (continuity) 0.5 else 0) / sigma_U
                1 - pnorm(z0)
              },
              "less" = {
                z0 <- (U - mu_U + if (continuity) 0.5 else 0) / sigma_U
                pnorm(z0)
              })

  p_val <- z

  # Preparar salida compatible
  nombres <- c("Grupo1", "Grupo2")
  medias <- c(mean(grupo1), mean(grupo2))
  names(medias) <- nombres
  orden <- order(medias, decreasing = TRUE)
  etiquetas_ordenadas <- names(medias)[orden]

  sig <- ifelse(p_val < alpha, "*", "ns")

  resultados <- data.frame(
    Comparacion = paste(nombres[1], nombres[2], sep = " - "),
    Diferencia = abs(medias[1] - medias[2]),
    Valor_Critico = NA,  # no aplica directamente
    p_value = round(p_val, 4),
    Significancia = sig,
    stringsAsFactors = FALSE
  )

  out <- list(
    Resultados = resultados,
    Promedios = medias,
    Orden_Medias = etiquetas_ordenadas,
    Metodo = paste("Mann Whitney U (", alternative, ", manual)", sep = "")
  )
  class(out) <- c("comparacion", "mannwhitney")

  return(out)
}
