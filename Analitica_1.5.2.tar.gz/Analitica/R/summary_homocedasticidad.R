#' @export
summary.homocedasticidad <- function(object, ...) {
  cat("\n--- Homoscedasticity Test ---\n\n")
  cat("Method applied       :", object$Metodo, "\n")

  # Display the appropriate test statistic
  if (grepl("Levene", object$Metodo, ignore.case = TRUE)) {
    cat("F Statistic          :", object$Estadistico, "\n")
    cat("Degrees of freedom   :",
        object$gl["df_between"], "between groups,",
        object$gl["df_within"], "within groups\n")
  } else if (grepl("Bartlett", object$Metodo, ignore.case = TRUE) ||
             grepl("Fligner", object$Metodo, ignore.case = TRUE)) {
    cat("Chi-squared Statistic:", object$Estadistico, "\n")
    cat("Degrees of freedom   :", object$gl, "\n")
  } else {
    cat("Test Statistic       :", object$Estadistico, "\n")
    cat("Degrees of freedom   :", object$gl, "\n")
  }

  # Show p-value and decision
  cat("p-value              :", object$p_value, "\n")
  cat("Decision (alpha = 0.05):", object$Decision, "\n")
  cat("------------------------------------\n")
}
