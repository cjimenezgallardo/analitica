#' Bartlett Test for Homogeneity of Variances (implemented manually)
#'
#' Performs Bartlett test to assess the homogeneity of variances between groups.
#' This implementation does not use bartlett.test().
#'
#' @param modelo An object from \code{aov} or \code{lm}.
#' @param alpha Significance level (default = 0.05).
#'
#' @return A list of class \code{"bartlett"} with:
#' \describe{
#'   \item{Estadistico}{Chi-squared statistic.}
#'   \item{gl}{Degrees of freedom.}
#'   \item{p_value}{P-value for the test.}
#'   \item{Decision}{"Varianzas diferentes" or "Iguales varianzas"}
#' }
#'
#' @importFrom stats pchisq var
#'
#' @export
#'
#' @examples
#' data(d_e, package = "Analitica")
#' mod <- aov(Sueldo_actual ~ as.factor(labor), data = d_E) # labor is numeric
#' resultado <- BartlettTest(mod)
#' summary(resultado)
#'
#'
#'
BartlettTest <- function(modelo, alpha = 0.05) {

  if (!inherits(modelo, c("aov", "lm"))) {
    stop("The object must be the result of `aov()` or `lm()`.")
  }
  factor_name <- names(modelo$xlevels)[1]

  if (is.null(factor_name)) {
    stop("No grouping variable of type factor was found in the model.")
  }
  grupos <- modelo$model[[factor_name]]
  respuesta <- modelo$model[[1]]

  grupo_niveles <- unique(grupos)
  k <- length(grupo_niveles)

  n <- tapply(respuesta, grupos, length)
  s2 <- tapply(respuesta, grupos, var)
  N <- sum(n)

  # Ponderar log(varianzas)
  num <- (n - 1) * log(s2)
  sum_num <- sum(num)

  # Varianza combinada (ponderada)
  s2_pooled <- sum((n - 1) * s2) / (N - k)

  # Estadistico de Bartlett
  A <- (N - k) * log(s2_pooled) - sum_num
  C <- 1 + (1 / (3 * (k - 1))) * (sum(1 / (n - 1)) - (1 / (N - k)))
  X2 <- A / C

  gl <- k - 1
  p_val <- 1 - pchisq(X2, df = gl)
  decision <- ifelse(p_val < alpha, "Heterocedastic", "Homocedastic")

  out <- list(
    Estadistico = round(X2, 4),
    gl = gl,
    p_value = round(p_val, 4),
    Decision = decision,
    Metodo = "Bartlett"
  )
  class(out) <- "homocedasticidad"
  return(out)
}
