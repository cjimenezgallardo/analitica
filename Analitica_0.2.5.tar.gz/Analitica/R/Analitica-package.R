#' Analitica: es una Herramientas de Análisis y Visualización de Datos
#'
#' Este paquete proporciona funciones para análisis estadístico descriptivo y visualización
#' de variables numéricas, con o sin variable independiente.
#' También encontraras métodos para la validación de OutLiers
#'
#'
#' @section Funciones principales:
#' - \code{\link{descripYG}}: Analisis descriptivo con visualizacion.
#' - \code{\link{grubbs_outliers}}: Deteccion de todos los outliers de acuerdo al metodo de Grubbs
#'
#'
#' @name Analitica
#' @author Carlos Jiménez-Gallardo
#' @keywords package
NULL
