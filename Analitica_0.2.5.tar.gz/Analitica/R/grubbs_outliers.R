#' Deteccion de Outliers con el metodo de Grubbs
#'
#' Esta funcion detecta valores atipicos (outliers) en una variable numerica
#' utilizando el procedimiento de Grubbs.
#'
#' @param dataSet Un \code{data.frame} que contiene los datos.
#' @param vD Variable dependiente numerica sin comillas (ej. \code{Sueldo_actual}).
#' @param alpha Nivel de significancia numerico para el test (por defecto \code{0.05}).
#'
#' @return Un \code{data.frame} con una columna adicional llamada \code{outL}
#' que indica con \code{TRUE} las observaciones identificadas como outliers.
#'
#' @details
#' La funcion aplica test de Grubbs hasta encontrar todos los posibles
#' outliers significativos al nivel de \code{alpha} especificado.
#'
#' @examples
#' data(d_e, package = "Analitica")
#' grubbs_outliers(d_E, Sueldo_actual)
#'
#' @export
#' @importFrom stats qt
#' @importFrom rlang enquo
#' @importFrom rlang as_name
#'
#'
grubbs_outliers <- function(dataSet, vD, alpha = 0.05) {
  vD_quo <- rlang::enquo(vD)
  vD_name <- rlang::as_name(vD_quo)

  if (!vD_name %in% colnames(dataSet)) {
    stop("La variable especificada no existe en el data.frame.")
  }

  valores <- dataSet[[vD_name]]

  if (!is.numeric(valores)) {
    stop("La variable debe ser numerica.")
  }

  dataSet$outL <- FALSE
  indices <- seq_along(valores)

  grubbs_stat <- function(x, alpha) {
    n <- length(x)
    if (n < 3) return(list(G = 0, G_c = Inf))  # tamaño minimo de la muestra es de 3
    G <- max(abs(x - mean(x))) / sd(x)
    t_c <- qt(1 - alpha / (2 * n), df = n - 2)
    G_c <- ((n - 1) / sqrt(n)) * sqrt(t_c^2 / (n - 2 + t_c^2))
    return(list(G = G, G_c = G_c))
  }

  repeat {
    g <- grubbs_stat(valores, alpha)

    if (g$G > g$G_c) {
      idx_outlier <- which.max(abs(valores - mean(valores)))
      idx_original <- indices[idx_outlier]
      dataSet$outL[idx_original] <- TRUE
      valores <- valores[-idx_outlier]
      indices <- indices[-idx_outlier]
    } else {
      break
    }
  }

  return(dataSet)
}
