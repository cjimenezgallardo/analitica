#' Fligner-Killeen Test for Homogeneity of Variances (manual, formula + data) v 1.5
#'
#' Performs a non-parametric Fligner-Killeen test for equality of variances across groups.
#' Very robust to non-normality and outliers.
#'
#' @param formula A formula of the form y ~ group
#' @param data A data frame containing the variables.
#' @param alpha Significance level (default = 0.05).
#'
#' @return A list of class \code{"homogeneity"} with:
#' \describe{
#'   \item{Statistic}{Chi-squared test statistic.}
#'   \item{df}{Degrees of freedom.}
#'   \item{p_value}{P-value of the test.}
#'   \item{Decision}{"Homoscedastic" or "Heteroscedastic".}
#'   \item{Method}{Test method used.}
#' }
#'
#' @importFrom stats model.frame
#'
#' @export
#'
#' @examples
#' data(d_e, package = "Analitica")
#' res <- FKTest(Sueldo_actual~labor,data=d_E)
#' summary(res)
#'
FKTest <- function(formula, data, alpha = 0.05) {

  if (missing(formula) || missing(data)) {
    stop("Both 'formula' and 'data' must be provided.")
  }

  mf <- model.frame(formula, data)
  if (ncol(mf) != 2) {
    stop("Formula must be of the form 'response ~ group'.")
  }

  y <- mf[[1]]
  group <- as.factor(mf[[2]])
  group_levels <- levels(group)
  k <- length(group_levels)

  if (!is.numeric(y)) {
    stop("The response variable must be numeric.")
  }

  # Median per group
  medians <- tapply(y, group, median)

  # Compute absolute deviations from group medians
  z <- abs(y - medians[group])

  # Rank the deviations
  ranks <- rank(z)

  # Apply log transformation
  log_ranks <- log(ranks + 0.5)

  # Group and global means
  overall_mean <- mean(log_ranks)
  group_means <- tapply(log_ranks, group, mean)
  n <- tapply(log_ranks, group, length)

  # Fligner-Killeen test statistic
  X2 <- sum(n * (group_means - overall_mean)^2)

  df <- k - 1
  p_val <- 1 - pchisq(X2, df)
  decision <- ifelse(p_val < alpha, "Heteroscedastic", "Homoscedastic")

  out <- list(
    Statistic = round(X2, 4),
    df = df,
    p_value = round(p_val, 4),
    Decision = decision,
    Method = "Fligner-Killeen"
  )
  class(out) <- "homocedasticidad"
  return(out)
}
