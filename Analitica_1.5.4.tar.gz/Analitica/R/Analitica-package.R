#' Analitica: Exploratory Analysis Procedures and Comparative Processes
#'
#' This package provides functions for descriptive statistical analysis and visualization
#' of numerical variables, with or without an independent variable.
#' You will also find methods for outlier validation and procedures
#' related to comparative analysis.
#'
#' @section Main functions:
#' - \code{\link{descripYG}}: Descriptive analysis with visualization.
#' - \code{\link{Levene.Test}}: Manual implementation of Levene's test.
#' - \code{\link{BartlettTest}}: Manual implementation of Bartlett's test.
#'
#'
#'
#' @name Analitica
#' @author Carlos Jiménez-Gallardo
#' @keywords package
NULL
