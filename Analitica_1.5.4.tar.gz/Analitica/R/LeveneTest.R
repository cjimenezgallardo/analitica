#' Levene Test for Homogeneity of Variances (manual, formula + data) v 1.5
#'
#' Performs Levene's test for equality of variances using a formula and data frame.
#' It uses absolute deviations from the group median (default) or mean.
#'
#' @param formula A formula of the form y ~ group
#' @param data A data frame containing the variables.
#' @param alpha Significance level (default = 0.05).
#' @param center Use "median" (default) or "mean" for deviation calculation.
#'
#' @return A list of class \code{"homocedasticidad"} with test results.
#'
#' @importFrom stats model.frame
#'
#' @export
#'
#' @examples
#' data(d_e, package = "Analitica")
#' res<-Levene.Test(Sueldo_actual~labor,data=d_E)
#' summary(res)
#'
Levene.Test <- function(formula, data, alpha = 0.05, center = "median") {

  if (missing(formula) || missing(data)) {
    stop("Both 'formula' and 'data' must be provided.")
  }

  if (!center %in% c("median", "mean")) {
    stop("The 'center' parameter must be either 'median' or 'mean'.")
  }

  mf <- model.frame(formula, data)
  if (ncol(mf) != 2) {
    stop("Formula must be of the form 'response ~ group'.")
  }

  y <- mf[[1]]
  group <- as.factor(mf[[2]])
  group_levels <- levels(group)

  if (!is.numeric(y)) {
    stop("The response variable must be numeric.")
  }

  # Absolute deviations from center
  z <- numeric(length(y))
  for (g in group_levels) {
    idx <- group == g
    center_value <- if (center == "mean") mean(y[idx]) else median(y[idx])
    z[idx] <- abs(y[idx] - center_value)
  }

  # ANOVA on absolute deviations
  df_total <- length(z) - 1
  df_between <- length(group_levels) - 1
  df_within <- df_total - df_between

  mean_z <- tapply(z, group, mean)
  n <- tapply(z, group, length)
  overall_mean <- mean(z)

  SS_between <- sum(n * (mean_z - overall_mean)^2)
  SS_within <- sum((z - rep(mean_z, times = n))^2)

  MS_between <- SS_between / df_between
  MS_within <- SS_within / df_within

  F_stat <- MS_between / MS_within
  p_val <- 1 - pf(F_stat, df_between, df_within)

  decision <- ifelse(p_val < alpha, "Heteroscedastic", "Homoscedastic")

  out <- list(
    Statistic = round(F_stat, 4),
    df = c(df_between = df_between, df_within = df_within),
    p_value = round(p_val, 4),
    Decision = decision,
    Method = paste("Levene (", center, ")", sep = "")
  )
  class(out) <- "homocedasticidad"
  return(out)
}
