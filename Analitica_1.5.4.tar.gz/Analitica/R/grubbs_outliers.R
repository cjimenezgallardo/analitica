#' Outlier Detection Using Grubbs' Test
#'
#' This function detects outliers in a numeric variable
#' using the Grubbs test procedure. It is useful for data with a NORMAL distribution.
#'
#' @param dataSet A \code{data.frame} containing the data.
#' @param vD Numeric dependent variable, unquoted (e.g., \code{Sueldo_actual}).
#' @param alpha Numeric significance level for the test (default is \code{0.05}).
#'
#' @return A \code{data.frame} with an additional column named \code{outL},
#' indicating with \code{TRUE} the observations identified as outliers.
#'
#' @details
#' The function applies Grubbs' test iteratively until all significant
#' outliers are found at the specified \code{alpha} level.
#'
#' @importFrom stats qt
#' @importFrom rlang enquo
#' @importFrom rlang as_name
#'
#' @export
#' @examples
#' data(d_e, package = "Analitica")
#' grubbs_outliers(d_E, Sueldo_actual)#'
#'
grubbs_outliers <- function(dataSet, vD, alpha = 0.05) {
  vD_quo <- rlang::enquo(vD)
  vD_name <- rlang::as_name(vD_quo)

  if (!vD_name %in% colnames(dataSet)) {
    stop("The specified variable does not exist in the data frame.")
  }

  valores <- dataSet[[vD_name]]

  if (!is.numeric(valores)) {
    stop("The specified variable must be numeric.")
  }

  dataSet$outL <- FALSE
  indices <- seq_along(valores)

  grubbs_stat <- function(x, alpha) {
    n <- length(x)
    if (n < 3) return(list(G = 0, G_c = Inf))  # tamaño minimo de la muestra es de 3
    G <- max(abs(x - mean(x))) / sd(x)
    t_c <- qt(1 - alpha / (2 * n), df = n - 2)
    G_c <- ((n - 1) / sqrt(n)) * sqrt(t_c^2 / (n - 2 + t_c^2))
    return(list(G = G, G_c = G_c))
  }

  repeat {
    g <- grubbs_stat(valores, alpha)

    if (g$G > g$G_c) {
      idx_outlier <- which.max(abs(valores - mean(valores)))
      idx_original <- indices[idx_outlier]
      dataSet$outL[idx_original] <- TRUE
      valores <- valores[-idx_outlier]
      indices <- indices[-idx_outlier]
    } else {
      break
    }
  }

  return(dataSet)
}
