#' Brunner-Munzel Test for Two Independent Groups (Permutation Version)
#'
#' Performs the Brunner-Munzel test using a permutation approach.
#'
#' @param grupo1 Numeric vector for the first group.
#' @param grupo2 Numeric vector for the second group.
#' @param alpha Significance level (default = 0.05).
#' @param alternative alternative Hypothesis: "two.sided", "greater", or "less".
#' @param nperm Number of permutations (default = 10000).
#'
#' @return An object of class \code{"comparacion"}.
#'
#' importFrom
#'
#' @export
#'
#'
#'
#'
#'
BMTest_perm <- function(grupo1, grupo2, alpha = 0.05,
                        alternative = c("two.sided", "less", "greater"),
                        nperm = 10000) {
  alternative <- match.arg(alternative)

  m <- length(grupo1)
  n <- length(grupo2)
  datos <- c(grupo1, grupo2)
  total <- m + n

  # Función para calcular el estadístico Brunner-Munzel
  calc_stat <- function(x, y) {
    datos <- c(x, y)
    ranks <- rank(datos)
    R1 <- ranks[1:length(x)]
    R2 <- ranks[(length(x)+1):length(datos)]

    R1_media <- mean(R1)
    R2_media <- mean(R2)

    S1_sq <- sum((R1 - R1_media)^2) / (length(x) - 1)
    S2_sq <- sum((R2 - R2_media)^2) / (length(y) - 1)
    S_sq <- (S1_sq / length(x)) + (S2_sq / length(y))
    T_stat <- (R1_media - R2_media) / sqrt(S_sq)
    return(T_stat)
  }

  # Estadístico observado
  T_obs <- calc_stat(grupo1, grupo2)

  # Permutaciones
  set.seed(123)
  T_perm <- numeric(nperm)
  for (i in 1:nperm) {
    indices <- sample(total)
    x_perm <- datos[indices[1:m]]
    y_perm <- datos[indices[(m+1):total]]
    T_perm[i] <- calc_stat(x_perm, y_perm)
  }

  # Valor-p empírico
  if (alternative == "two.sided") {
    p_val <- mean(abs(T_perm) >= abs(T_obs))
  } else if (alternative == "greater") {
    p_val <- mean(T_perm >= T_obs)
  } else {
    p_val <- mean(T_perm <= T_obs)
  }

  # Resultados
  nombres <- c("Grupo1", "Grupo2")
  medias <- c(mean(grupo1), mean(grupo2))
  names(medias) <- nombres
  orden <- order(medias, decreasing = TRUE)
  etiquetas_ordenadas <- names(medias)[orden]
  diferencia <- abs(diff(medias))
  sig <- ifelse(p_val < alpha, "*", "ns")

  resultados <- data.frame(
    Comparacion = paste(nombres[1], nombres[2], sep = " - "),
    Diferencia = diferencia,
    Valor_Critico = NA,
    p_value = round(p_val, 4),
    Sig = sig,
    stringsAsFactors = FALSE
  )

  out <- list(
    Resultados = resultados,
    Promedios = medias,
    Orden_Medias = etiquetas_ordenadas,
    Metodo = paste("Brunner-Munzel permutado (", alternative, ")", sep = "")
  )
  class(out) <- c("comparacion", "brunnermunzel_perm")
  return(out)
}
