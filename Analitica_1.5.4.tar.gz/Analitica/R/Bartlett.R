#' Bartlett Test for Homogeneity of Variances (implemented manually) v 1.5
#'
#' Performs Bartlett test using raw vectors instead of a model object.
#'
#' @param formula A formula of the form y ~ grupo
#' @param data A data frame containing the variables.
#' @param alpha Significance level (default = 0.05).
#'
#' @return A list of class \code{"homocedasticidad"} with test results.
#' \describe{
#'   \item{Statistic}{Chi-squared statistic.}
#'   \item{df}{Degrees of freedom.}
#'   \item{p_value}{P-value for the test.}
#'   \item{Decision}{"Varianzas diferentes" or "Iguales varianzas"}
#' }
#'
#' @importFrom stats pchisq var model.frame
#'
#' @export
#'
#' @examples
#' data(d_e, package = "Analitica")
#' res<-BartlettTest(Sueldo_actual~labor,data=d_E)
#' summary(res)
#'
#'
#'
BartlettTest <- function(formula, data, alpha = 0.05) {

  if (missing(formula) || missing(data)) {
    stop("Both 'formula' and 'data' must be provided.")
  }

  mf <- model.frame(formula, data)
  if (ncol(mf) != 2) {
    stop("Formula must be of the form 'response ~ group'.")
  }

  y <- mf[[1]]
  group <- mf[[2]]

  if (!is.numeric(y)) {
    stop("The response variable must be numeric.")
  }

  group <- as.factor(group)
  k <- nlevels(group)

  if (k < 2) {
    stop("The grouping variable must have at least two levels.")
  }

  n <- tapply(y, group, length)
  s2 <- tapply(y, group, var)
  N <- sum(n)

  # Cálculos del test
  num <- (n - 1) * log(s2)
  sum_num <- sum(num)

  s2_pooled <- sum((n - 1) * s2) / (N - k)

  A <- (N - k) * log(s2_pooled) - sum_num
  C <- 1 + (1 / (3 * (k - 1))) * (sum(1 / (n - 1)) - (1 / (N - k)))
  X2 <- A / C

  df <- k - 1
  p_val <- 1 - pchisq(X2, df = df)
  decision <- ifelse(p_val < alpha, "Heterocedastic", "Homocedastic")

  out <- list(
    Statistic = round(X2, 4),
    df = df,
    p_value = round(p_val, 4),
    Decision = decision,
    Method = "Bartlett"
  )
  class(out) <- "homocedasticidad"
  return(out)
}
