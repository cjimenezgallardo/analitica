#' Scheffe Test for Multiple Comparisons
#'
#' Performs Scheffe parametric post hoc test after an ANOVA model. It returns pairwise comparisons
#' between treatment means, indicating significant differences using a critical value based
#' on the F-distribution.
#' The Scheffe test is more flexible but less powerful than other post hoc tests
#' (such as Tukey or Bonferroni), which means it is more difficult to detect significant
#' differences, but it reduces the risk of false positives.
#' It is especially useful when group comparisons have not been planned in advance.
#' It has no limit on the number of comparisons.
#' Requirements: Normality of the dependent variable, homoscedasticity
#'
#' @param modelo An object from \code{aov} or \code{lm} representing an ANOVA model.
#' @param alpha Significance level (default is 0.05).
#'
#' @return An object of class \code{"scheffe"} (also class \code{"comparacion"}) with:
#' \describe{
#'   \item{Resultados}{A data frame of pairwise comparisons with difference, critical value, and significance.}
#'   \item{Promedios}{A named vector of group means.}
#'   \item{Orden_Medias}{Names of groups ordered from highest to lowest mean.}
#'   \item{Metodo}{Name of the test used ("Scheffe").}
#' }
#'
#' @importFrom dplyr group_by summarize mutate arrange
#' @importFrom stats sd qf deviance pf
#' @importFrom utils combn
#' @importFrom ggplot2 ggplot aes geom_bar geom_errorbar geom_text labs theme_minimal theme element_text
#'
#'
#' @export
#' @examples
#' data(d_e, package = "Analitica")
#' mod <- aov(Sueldo_actual ~ as.factor(labor), data = d_E) # labor is numeric
#' resultado <- ScheffeTest(mod)
#' summary(resultado)
#' plot(resultado)
#'
ScheffeTest <- function(modelo, alpha = 0.05) {

  factor_name <- names(modelo$xlevels)[1]
  grupos <- modelo$model[[factor_name]]
  respuesta <- modelo$model[[1]]

  medias <- tapply(respuesta, grupos, mean)
  n <- tapply(respuesta, grupos, length)
  nombres_grupos <- names(medias)
  orden_medias <- order(medias, decreasing = TRUE)
  etiquetas_ordenadas <- names(medias)[orden_medias]

  v1 <- modelo$rank - 1
  v2 <- modelo$df.residual
  Fcrit <- qf(1 - alpha, v1, v2)
  MSerror <- deviance(modelo) / v2
  comparaciones <- combn(names(medias), 2, simplify = FALSE)

  resultados <- data.frame(Comparacion = character(),
                           Diferencia = numeric(),
                           Valor_Critico = numeric(),
                           p_value = numeric(),
                           Significancia = character(),
                           stringsAsFactors = FALSE)

  for (par in comparaciones) {
    grupo1 <- par[1]
    grupo2 <- par[2]
    dif <- abs(medias[grupo1] - medias[grupo2])
    SE<-(MSerror * (1/n[grupo1] + 1/n[grupo2]))
    Fobs <- (dif^2) / SE
    valor_critico <- sqrt(v1 * Fcrit * SE)
    sig <- ifelse(dif > valor_critico, "*", "ns")
    p_val <- 1 - pf(Fobs, v1, v2)
    comp <- paste(grupo1, grupo2, sep = " - ")

    resultados <- rbind(resultados, data.frame(Comparacion = comp,
                                               Diferencia = dif,
                                               Valor_Critico = valor_critico,
                                               p_value = round(p_val, 4),
                                               Significancia = sig))
  }

  # Retornar como objeto con clase 'scheffe'
  out <- list(
    Resultados = resultados,
    Promedios = medias,
    Orden_Medias = etiquetas_ordenadas,
    Metodo = "Scheffe"
  )
  class(out) <- c("comparacion", "scheffe")

  return(out)
}

