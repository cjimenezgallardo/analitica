#' Bar Plot with Error Bars
#'
#' Generates a bar plot with error bars using the mean and either the standard deviation
#' or the standard error for each group.
#'
#' @param dataSet A \code{data.frame} or \code{tibble} containing the data.
#' @param vD Name of the numeric dependent variable (as a string).
#' @param vI Name of the categorical independent variable (as a string).
#' @param variation Type of error to display: \code{"sd"} (standard deviation)
#'   or \code{"se"} (standard error). Default is \code{"sd"}.
#' @param title Plot title.
#' @param label_y Y-axis label.
#' @param label_x X-axis label.
#'
#' @return A \code{ggplot} object.
#'
#' @export
#'
#' @importFrom dplyr group_by summarize mutate n
#' @importFrom ggplot2 ggplot aes geom_bar geom_errorbar geom_text labs theme_minimal theme element_text
#' @importFrom rlang ensym
#'
#' @examples
#' data(d_e, package = "Analitica")
#' bar_error(d_E, vD = "Sueldo_actual", vI = "labor", variation = "sd")
#'
bar_error <- function(dataSet, vD, vI, variation = "sd",
                      title = "Grafico de barras con error",
                      label_y = "Eje Y", label_x = "Eje X") {

  # Validar argumento 'variation'
  if (!variation %in% c("sd", "se")) {
    stop("El argumento 'variation' debe ser 'sd' o 'se'.")
  }

  # Validar que las variables existen en el dataset
  if (!(vD %in% names(dataSet))) stop(paste("Variable dependiente no encontrada:", vD))
  if (!(vI %in% names(dataSet))) stop(paste("Variable independiente no encontrada:", vI))

  # Convertir nombres a simbolos
  vD_sym <- rlang::ensym(vD)
  vI_sym <- rlang::ensym(vI)

  # Resumen estadistico por grupo
  summary_data <- dataSet %>%
    dplyr::group_by(!!vI_sym) %>%
    dplyr::summarize(
      mean = mean(!!vD_sym, na.rm = TRUE),
      sd = sd(!!vD_sym, na.rm = TRUE),
      n = dplyr::n(),
      se = sd / sqrt(n),
      .groups = "drop"
    )

  # Seleccionar la variacion
  summary_data$variacion <- if (variation == "sd") summary_data$sd else summary_data$se

  # Construccion del grafico
  p <- ggplot2::ggplot(summary_data, ggplot2::aes(x = !!vI_sym, y = mean)) +
    ggplot2::geom_bar(stat = "identity", fill = "steelblue", width = 0.7) +
    ggplot2::geom_errorbar(ggplot2::aes(ymin = mean - variacion, ymax = mean + variacion), width = 0.2) +
    ggplot2::geom_text(ggplot2::aes(label = round(mean, 2)), vjust = -0.5, size = 3.5) +
    ggplot2::labs(title = title, x = label_x, y = label_y) +
    ggplot2::theme_minimal() +
    ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5, face = "bold"))

  return(p)
}
