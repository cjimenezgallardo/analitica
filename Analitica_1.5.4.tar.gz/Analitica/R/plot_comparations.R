#' Generic plot for comparison-based tests
#'
#' @param x An object of class 'comparacion'.
#' @param ... Additional arguments (currently unused).
#' @export
#' @importFrom ggplot2 ggplot aes geom_bar geom_errorbar geom_text labs theme_minimal theme element_text ylim
#'
#' @examples
#' data(d_e, package = "Analitica")
#' mod <- aov(Sueldo_actual ~ as.factor(labor), data = d_E) # labor is numeric
#' resultado <- ScheffeTest(mod)
#' plot(resultado)
#'
plot.comparacion <- function(x, ...) {

  resultados <- x$Resultados
  promedios <- x$Promedios
  orden <- x$Orden_Medias
  metodo <- if (!is.null(x$Metodo)) x$Metodo else "Comparacion"

  # Reordenar promedios
  df_medias <- data.frame(
    Grupo = names(promedios),
    Media = as.numeric(promedios),
    stringsAsFactors = FALSE
  )
  df_medias <- df_medias[orden, ]
  rownames(df_medias) <- NULL

  # Asignar letras por similitud (igual que antes)
  letras <- rep("", length(promedios))
  names(letras) <- df_medias$Grupo
  letra_actual <- "a"
  grupos_asignados <- list()

  for (i in seq_along(df_medias$Grupo)) {
    g1 <- df_medias$Grupo[i]
    letra_asignada <- FALSE

    for (grupo_letra in names(grupos_asignados)) {
      mismo_grupo <- TRUE
      for (g2 in grupos_asignados[[grupo_letra]]) {
        comp <- paste(sort(c(g1, g2)), collapse = " - ")
        sig <- resultados$Significancia[resultados$Comparacion == comp]
        if (length(sig) > 0 && any(sig == "*")) {
          mismo_grupo <- FALSE
          break
        }
      }

      if (mismo_grupo) {
        letras[g1] <- paste0(letras[g1], grupo_letra)
        grupos_asignados[[grupo_letra]] <- c(grupos_asignados[[grupo_letra]], g1)
        letra_asignada <- TRUE
        break
      }
    }

    if (!letra_asignada) {
      letras[g1] <- letra_actual
      grupos_asignados[[letra_actual]] <- c(g1)
      letra_actual <- intToUtf8(utf8ToInt(letra_actual) + 1)
    }
  }

  df_medias$Letra <- letras[df_medias$Grupo]
  df_medias$Grupo <- factor(df_medias$Grupo, levels = df_medias$Grupo)

  ggplot(df_medias, aes(x = Grupo, y = Media)) +
    geom_bar(stat = "identity", fill = "steelblue", width = 0.6) +
    geom_text(aes(label = Letra), vjust = -0.5, size = 5) +
    theme_minimal() +
    labs(
      title = paste("Promedios por grupo - Letras segun", metodo),
      x = "Grupo", y = "Media"
    ) +
    ggplot2::ylim(0, max(df_medias$Media) * 1.1)
}
