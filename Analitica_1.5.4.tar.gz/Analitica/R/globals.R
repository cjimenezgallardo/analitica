utils::globalVariables(c("variacion", "Grupo", "Media", "Letra", "ylim"))
