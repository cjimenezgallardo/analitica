#' @export
summary.homocedasticidad <- function(object, ...) {
  cat("\n--- Homoscedasticity Test ---\n\n")

  # Safe extraction of fields with fallback values
  method <- if (!is.null(object$Method)) object$Method else "Unknown"
  stat   <- if (!is.null(object$Statistic)) object$Statistic else NA
  df     <- object$df
  pval   <- if (!is.null(object$p_value)) object$p_value else NA
  decision <- if (!is.null(object$Decision)) object$Decision else "[Not available]"

  cat("Method applied       :", method, "\n")

  if (grepl("Levene", method, ignore.case = TRUE)) {
    cat("F Statistic          :", stat, "\n")
    if (is.numeric(df) && length(df) == 2 && all(c("df_between", "df_within") %in% names(df))) {
      cat("Degrees of freedom   :", df["df_between"], "between groups,",
          df["df_within"], "within groups\n")
    } else {
      cat("Degrees of freedom   : [Invalid or missing]\n")
    }
  } else if (grepl("Bartlett", method, ignore.case = TRUE) ||
             grepl("Fligner", method, ignore.case = TRUE)) {
    cat("Chi-squared Statistic:", stat, "\n")
    cat("Degrees of freedom   :", if (!is.null(df)) df else "[Missing]", "\n")
  } else {
    cat("Test Statistic       :", stat, "\n")
    cat("Degrees of freedom   :", if (!is.null(df)) df else "[Missing]", "\n")
  }

  cat("p-value              :", pval, "\n")
  cat("Decision (alpha = 0.05):", decision, "\n")
  cat("------------------------------------\n")
}
