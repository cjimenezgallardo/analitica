#' Generic plot for comparison-based tests
#'
#' Generates a bar plot of group means with significance letters assigned
#' based on post-hoc comparison results.
#'
#' @param x An object of class 'comparaciones'.
#' @param ... Additional arguments (currently unused).
#'
#' @return A \code{ggplot} object showing group means with assigned significance letters.
#' The plot illustrates the differences between groups according to the comparison method used.
#'
#' @export
#' @importFrom ggplot2 ggplot aes geom_bar geom_text labs theme_minimal coord_cartesian
#'
#' @examples
#' data(d_e, package = "Analitica")
#' mod <- aov(Sueldo_actual ~ as.factor(labor), data = d_e)
#' resultado <- GHTest(mod)
#' plot(resultado)
plot.comparaciones <- function(x, ...) {
  if (!inherits(x, "comparaciones")) {
    stop("El objeto debe ser de clase 'comparaciones'")
  }

  resultados <- x$Resultados
  promedios <- x$Promedios
  orden <- x$Orden_Medias
  metodo <- if (!is.null(x$Metodo)) x$Metodo else "Comparaciones"

  # Normalizar nombres de comparaciones
  resultados$Comparacion <- sapply(strsplit(resultados$Comparacion, " - "),
                                   function(p) paste(sort(p), collapse = " - "))

  # Preparar dataframe de medias
  df_medias <- data.frame(
    Grupo = names(promedios),
    Media = as.numeric(promedios),
    stringsAsFactors = FALSE
  )
  df_medias <- df_medias[match(orden, df_medias$Grupo), ]
  rownames(df_medias) <- NULL

  # Asignar letras segun significancia
  letras <- rep("", nrow(df_medias))
  names(letras) <- df_medias$Grupo
  letra_actual <- "a"
  grupos_asignados <- list()

  for (i in seq_along(df_medias$Grupo)) {
    g1 <- df_medias$Grupo[i]
    letra_asignada <- FALSE

    for (grupo_letra in names(grupos_asignados)) {
      mismo_grupo <- TRUE
      for (g2 in grupos_asignados[[grupo_letra]]) {
        comp <- paste(sort(c(g1, g2)), collapse = " - ")
        sig <- resultados$Significancia[resultados$Comparacion == comp]
        if (length(sig) > 0 && any(sig %in% c("*", "**", "***"))) {
          mismo_grupo <- FALSE
          break
        }
      }

      if (mismo_grupo) {
        letras[g1] <- paste0(letras[g1], grupo_letra)
        grupos_asignados[[grupo_letra]] <- c(grupos_asignados[[grupo_letra]], g1)
        letra_asignada <- TRUE
        break
      }
    }

    if (!letra_asignada) {
      letras[g1] <- letra_actual
      grupos_asignados[[letra_actual]] <- c(g1)
      letra_actual <- intToUtf8(utf8ToInt(letra_actual) + 1)
    }
  }

  df_medias$Letra <- letras[df_medias$Grupo]
  df_medias$Grupo <- factor(df_medias$Grupo, levels = df_medias$Grupo)

  # Generar grafico
  ggplot(df_medias, aes(x = Grupo, y = Media)) +
    geom_bar(stat = "identity", fill = "steelblue", width = 0.6) +
    geom_text(aes(label = Letra), vjust = -0.5, size = 5) +
    theme_minimal() +
    labs(
      title = paste("Promedios por grupo - Letras segun", metodo),
      x = "Grupo", y = "Media"
    ) +
    coord_cartesian(ylim = c(0, max(df_medias$Media, na.rm = TRUE) * 1.1))
}

